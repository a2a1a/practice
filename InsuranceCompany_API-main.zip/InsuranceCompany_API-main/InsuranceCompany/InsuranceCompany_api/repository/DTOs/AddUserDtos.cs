﻿namespace InsuranceCompany_api.repository.DTOs
{
    public class AddUserDtos
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PersonalNumber { get; set; }
        public string Phone { get; set; }
    }
}
