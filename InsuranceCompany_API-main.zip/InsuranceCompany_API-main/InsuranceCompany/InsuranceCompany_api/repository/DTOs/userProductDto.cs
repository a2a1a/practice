﻿using InsuranceCompany_api.Data.Entity;

namespace InsuranceCompany_api.repository.DTOs
{
    public class userProductDto
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
    }
}
